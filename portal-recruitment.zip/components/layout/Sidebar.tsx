"use client";

import React, { useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { usePathname } from "next/navigation";
import {
  LayoutDashboard,
  Briefcase,
  Settings,
  Database,
  ChevronDown,
  ChevronRight,
  LogOut,
  Clock,
  ChevronLeft,
  Users,
  Archive,
  Contact,
  BarChart2,
  UserX,
  FileText,
  ShieldAlert,
  X,
} from "lucide-react";
import { useRouter } from "next/navigation";
import { useSession, signOut } from "next-auth/react";

interface SidebarProps {
  isCollapsed: boolean;
  setIsCollapsed: (val: boolean) => void;
  isMobileOpen?: boolean;
  setIsMobileOpen?: (val: boolean) => void;
}

export default function Sidebar({
  isCollapsed,
  setIsCollapsed,
  isMobileOpen,
  setIsMobileOpen,
}: SidebarProps) {
  const pathname = usePathname();
  const router = useRouter();
  const { data: session } = useSession();

  // Track if Settings menu is expanded
  const [isSettingsOpen, setIsSettingsOpen] = useState(
    pathname.includes("/settings"),
  );

  // Track if Dashboard menu is expanded
  const [isDashboardOpen, setIsDashboardOpen] = useState(
    pathname === "/dashboard" ||
    pathname.includes("/dashboard/executive") ||
    pathname.includes("/dashboard/geosource") ||
    pathname.includes("/dashboard/calendar"),
  );

  const userRole = (session?.user as any)?.role?.toLowerCase() || null;

  const handleLogout = () => {
    signOut({ callbackUrl: "/login" });
  };

  const isMasterDataActive = pathname.includes("/settings/master-data");

  return (
    <>
      {/* Mobile Drawer Backdrop */}
      {isMobileOpen && (
        <div
          className="md:hidden fixed inset-0 bg-black/50 backdrop-blur-xs z-40 transition-opacity"
          onClick={() => setIsMobileOpen?.(false)}
          aria-hidden="true"
        />
      )}

      <aside
        className={`h-screen h-[100dvh] fixed left-0 top-0 bg-surface-container-lowest border-r border-table-border flex flex-col pt-4 pb-3 z-50 transition-all duration-300 ease-in-out ${
          isCollapsed ? "w-[80px]" : "w-[260px]"
        } ${
          isMobileOpen ? "translate-x-0 shadow-2xl" : "-translate-x-full md:translate-x-0"
        }`}
      >
        {/* Floating Collapse / Expand Toggle Button for Desktop (Top Edge) */}
        <button
          type="button"
          onClick={() => setIsCollapsed(!isCollapsed)}
          className="hidden md:flex absolute -right-3.5 top-5 w-7 h-7 bg-white border border-slate-300 text-slate-700 hover:text-primary hover:border-primary rounded-full items-center justify-center shadow-md hover:shadow-lg transition-all duration-200 z-50 cursor-pointer group"
          title={isCollapsed ? "Perluas Sidebar" : "Perkecil Sidebar"}
          aria-label={isCollapsed ? "Perluas Sidebar" : "Perkecil Sidebar"}
        >
          {isCollapsed ? (
            <ChevronRight className="w-4 h-4 transition-transform group-hover:translate-x-0.5" />
          ) : (
            <ChevronLeft className="w-4 h-4 transition-transform group-hover:-translate-x-0.5" />
          )}
        </button>

        {/* Brand Header with Logo + E Recruitment PT Dian Pandu Pratama */}
        <div
          className={`mb-5 flex items-center shrink-0 ${
            isCollapsed ? "justify-center px-0" : "px-4 justify-between"
          }`}
        >
          {isCollapsed ? (
            <Link
              href="/dashboard"
              className="flex items-center justify-center group"
              title="E-Recruitment PT Dian Pandu Pratama"
              aria-label="E-Recruitment PT Dian Pandu Pratama"
              onClick={() => setIsMobileOpen?.(false)}
            >
              <div className="w-10 h-10 bg-white rounded-md border border-slate-200/90 p-1 flex items-center justify-center shrink-0 shadow-2xs group-hover:border-[#D9232A]/50 transition-colors">
                <Image
                  src="/images/branding/dpp-icon.png"
                  alt="Logo PT Dian Pandu Pratama"
                  width={36}
                  height={36}
                  className="w-7 h-7 object-contain"
                  priority
                  unoptimized
                />
              </div>
            </Link>
          ) : (
            <div className="flex items-center justify-between w-full">
              <Link
                href="/dashboard"
                className="flex items-center gap-3 min-w-0 group"
                aria-label="E-Recruitment PT Dian Pandu Pratama"
                onClick={() => setIsMobileOpen?.(false)}
              >
                <div className="w-10 h-10 bg-white rounded-md border border-slate-200/90 p-1 flex items-center justify-center shrink-0 shadow-2xs group-hover:border-[#D9232A]/50 transition-colors">
                  <Image
                    src="/images/branding/dpp-icon.png"
                    alt="Logo PT Dian Pandu Pratama"
                    width={36}
                    height={36}
                    className="w-7 h-7 object-contain"
                    priority
                    unoptimized
                  />
                </div>
                <div className="flex flex-col min-w-0">
                  <div className="flex items-center gap-1.5">
                    <span className="font-extrabold text-[13px] tracking-tight text-slate-900 leading-tight">
                      E-Recruitment
                    </span>
                    <span className="px-1 py-0.2 text-[8px] font-bold bg-red-100 text-[#D9232A] rounded">
                      DPP
                    </span>
                  </div>
                  <span className="text-[10px] font-semibold text-slate-500 truncate leading-tight mt-0.5">
                    PT Dian Pandu Pratama
                  </span>
                </div>
              </Link>
              <button
                type="button"
                onClick={() => setIsMobileOpen?.(false)}
                className="md:hidden p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-md transition-colors"
                aria-label="Tutup navigasi"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          )}
        </div>

      {/* Navigation Links */}
      <nav className="flex-1 overflow-y-auto min-h-0 py-2 space-y-1">
        {/* Expandable Dashboard Menu */}
        <div className="pb-1">
          <button
            onClick={() => setIsDashboardOpen(!isDashboardOpen)}
            className={`w-full flex items-center justify-between px-6 py-3 transition-colors duration-200 text-left focus:outline-none ${pathname === "/dashboard" ||
                pathname.includes("/dashboard/executive") ||
                pathname.includes("/dashboard/geosource") ||
                pathname.includes("/dashboard/calendar")
                ? "text-primary font-bold"
                : "text-on-surface-variant hover:bg-surface-container-low"
              } ${isCollapsed ? "justify-center px-0" : ""}`}
            title={isCollapsed ? "Dashboard" : undefined}
          >
            <div
              className={`flex items-center ${isCollapsed ? "justify-center w-full" : ""}`}
            >
              <LayoutDashboard
                className={`${isCollapsed ? "" : "mr-3"} w-5 h-5 shrink-0`}
              />
              {!isCollapsed && (
                <span className="font-sans text-xs font-semibold">
                  Dashboard
                </span>
              )}
            </div>
            {!isCollapsed &&
              (isDashboardOpen ? (
                <ChevronDown className="w-4 h-4" />
              ) : (
                <ChevronRight className="w-4 h-4" />
              ))}
          </button>

          {isDashboardOpen && !isCollapsed && (
            <div className="bg-surface-container-low/30 py-1">
              <Link
                href="/dashboard/executive"
                className={`w-full flex items-center pl-14 pr-6 py-2 transition-colors duration-200 text-left focus:outline-none ${pathname.includes("/dashboard/executive") ||
                    pathname === "/dashboard"
                    ? "text-primary font-bold border-r-4 border-primary bg-surface-container-low/50"
                    : "text-on-surface-variant hover:bg-surface-container-low"
                  }`}
              >
                <span className="font-sans text-[11px] font-semibold">
                  Executive Dashboard
                </span>
              </Link>
              <Link
                href="/dashboard/geosource"
                className={`w-full flex items-center pl-14 pr-6 py-2 transition-colors duration-200 text-left focus:outline-none ${pathname.includes("/dashboard/geosource")
                    ? "text-primary font-bold border-r-4 border-primary bg-surface-container-low/50"
                    : "text-on-surface-variant hover:bg-surface-container-low"
                  }`}
              >
                <span className="font-sans text-[11px] font-semibold">
                  GeoSource Dashboard
                </span>
              </Link>
              <Link
                href="/dashboard/calendar"
                className={`w-full flex items-center pl-14 pr-6 py-2 transition-colors duration-200 text-left focus:outline-none ${pathname.includes("/dashboard/calendar")
                    ? "text-primary font-bold border-r-4 border-primary bg-surface-container-low/50"
                    : "text-on-surface-variant hover:bg-surface-container-low"
                  }`}
              >
                <span className="font-sans text-[11px] font-semibold">
                  Calendar
                </span>
              </Link>
            </div>
          )}
        </div>

        <Link
          href="/dashboard/job-openings"
          className={`w-full flex items-center px-6 py-3 transition-colors duration-200 text-left focus:outline-none ${pathname.includes("/dashboard/job-openings")
              ? "text-primary font-bold border-r-4 border-primary bg-surface-container-low/50"
              : "text-on-surface-variant hover:bg-surface-container-low"
            } ${isCollapsed ? "justify-center px-0" : ""}`}
          title={isCollapsed ? "Job Openings" : undefined}
        >
          <Briefcase
            className={`${isCollapsed ? "" : "mr-3"} w-5 h-5 shrink-0`}
          />
          {!isCollapsed && (
            <span className="font-sans text-xs font-semibold">
              Job Openings
            </span>
          )}
        </Link>

        <Link
          href="/dashboard/pipeline"
          className={`w-full flex items-center px-6 py-3 transition-colors duration-200 text-left focus:outline-none ${pathname.includes("/dashboard/pipeline")
              ? "text-primary font-bold border-r-4 border-primary bg-surface-container-low/50"
              : "text-on-surface-variant hover:bg-surface-container-low"
            } ${isCollapsed ? "justify-center px-0" : ""}`}
          title={isCollapsed ? "Pipeline" : undefined}
        >
          <Database
            className={`${isCollapsed ? "" : "mr-3"} w-5 h-5 shrink-0`}
          />
          {!isCollapsed && (
            <span className="font-sans text-xs font-semibold">Pipeline</span>
          )}
        </Link>

        <Link
          href="/dashboard/archived-candidates"
          className={`w-full flex items-center px-6 py-3 transition-colors duration-200 text-left focus:outline-none ${pathname.includes("/dashboard/archived-candidates")
              ? "text-primary font-bold border-r-4 border-primary bg-surface-container-low/50"
              : "text-on-surface-variant hover:bg-surface-container-low"
            } ${isCollapsed ? "justify-center px-0" : ""}`}
          title={isCollapsed ? "Archived Candidates" : undefined}
        >
          <Archive
            className={`${isCollapsed ? "" : "mr-3"} w-5 h-5 shrink-0`}
          />
          {!isCollapsed && (
            <span className="font-sans text-xs font-semibold">
              Archived Candidates
            </span>
          )}
        </Link>

        <Link
          href="/dashboard/blacklist"
          className={`w-full flex items-center px-6 py-3 transition-colors duration-200 text-left focus:outline-none ${pathname.includes("/dashboard/blacklist")
              ? "text-primary font-bold border-r-4 border-primary bg-surface-container-low/50"
              : "text-on-surface-variant hover:bg-surface-container-low"
            } ${isCollapsed ? "justify-center px-0" : ""}`}
          title={isCollapsed ? "Blacklist" : undefined}
        >
          <UserX className={`${isCollapsed ? "" : "mr-3"} w-5 h-5 shrink-0`} />
          {!isCollapsed && (
            <span className="font-sans text-xs font-semibold">Blacklist</span>
          )}
        </Link>

        <Link
          href="/dashboard/talent-pool"
          className={`w-full flex items-center px-6 py-3 transition-colors duration-200 text-left focus:outline-none ${pathname.includes("/dashboard/talent-pool")
              ? "text-primary font-bold border-r-4 border-primary bg-surface-container-low/50"
              : "text-on-surface-variant hover:bg-surface-container-low"
            } ${isCollapsed ? "justify-center px-0" : ""}`}
          title={isCollapsed ? "Talent Pool" : undefined}
        >
          <Contact
            className={`${isCollapsed ? "" : "mr-3"} w-5 h-5 shrink-0`}
          />
          {!isCollapsed && (
            <span className="font-sans text-xs font-semibold">Talent Pool</span>
          )}
        </Link>

        <Link
          href="/dashboard/interviews"
          className={`w-full flex items-center px-6 py-3 transition-colors duration-200 text-left focus:outline-none ${pathname.includes("/dashboard/interviews")
              ? "text-primary font-bold border-r-4 border-primary bg-surface-container-low/50"
              : "text-on-surface-variant hover:bg-surface-container-low"
            } ${isCollapsed ? "justify-center px-0" : ""}`}
          title={isCollapsed ? "Interviews" : undefined}
        >
          <Users className={`${isCollapsed ? "" : "mr-3"} w-5 h-5 shrink-0`} />
          {!isCollapsed && (
            <span className="font-sans text-xs font-semibold">Interviews</span>
          )}
        </Link>

        <Link
          href="/dashboard/generate-documents"
          className={`w-full flex items-center px-6 py-3 transition-colors duration-200 text-left focus:outline-none ${pathname.includes("/dashboard/generate-documents")
              ? "text-primary font-bold border-r-4 border-primary bg-surface-container-low/50"
              : "text-on-surface-variant hover:bg-surface-container-low"
            } ${isCollapsed ? "justify-center px-0" : ""}`}
          title={isCollapsed ? "Generate Documents" : undefined}
        >
          <FileText
            className={`${isCollapsed ? "" : "mr-3"} w-5 h-5 shrink-0`}
          />
          {!isCollapsed && (
            <span className="font-sans text-xs font-semibold">
              Generate Documents
            </span>
          )}
        </Link>

        {/* Expandable Settings Menu */}
        <div className="pt-2">
          <button
            onClick={() => setIsSettingsOpen(!isSettingsOpen)}
            className={`w-full flex items-center justify-between px-6 py-3 transition-colors duration-200 text-left focus:outline-none ${pathname.includes("/settings")
                ? "text-primary font-bold"
                : "text-on-surface-variant hover:bg-surface-container-low"
              } ${isCollapsed ? "justify-center px-0" : ""}`}
            title={isCollapsed ? "Settings" : undefined}
          >
            <div
              className={`flex items-center ${isCollapsed ? "justify-center w-full" : ""}`}
            >
              <Settings
                className={`${isCollapsed ? "" : "mr-3"} w-5 h-5 shrink-0`}
              />
              {!isCollapsed && (
                <span className="font-sans text-xs font-semibold">
                  Settings
                </span>
              )}
            </div>
            {!isCollapsed &&
              (isSettingsOpen ? (
                <ChevronDown className="w-4 h-4" />
              ) : (
                <ChevronRight className="w-4 h-4" />
              ))}
          </button>

          {isSettingsOpen && !isCollapsed && (
            <div className="bg-surface-container-low/30 py-1">
              <Link
                href="/dashboard/settings/master-data"
                className={`w-full flex items-center pl-14 pr-6 py-2 transition-colors duration-200 text-left focus:outline-none ${isMasterDataActive
                    ? "text-primary font-bold bg-surface-container-low/50"
                    : "text-on-surface-variant hover:bg-surface-container-low"
                  }`}
              >
                <Database className="mr-2 w-4 h-4 shrink-0" />
                <span className="font-sans text-[11px] font-semibold">
                  Master Data
                </span>
              </Link>
              {(userRole === "administrator" || userRole === "admin") && (
                <>
                  <Link
                    href="/dashboard/settings/users"
                    className={`w-full flex items-center pl-14 pr-6 py-2 transition-colors duration-200 text-left focus:outline-none ${pathname.includes("/settings/users")
                        ? "text-primary font-bold bg-surface-container-low/50"
                        : "text-on-surface-variant hover:bg-surface-container-low"
                      }`}
                  >
                    <Users className="mr-2 w-4 h-4 shrink-0" />
                    <span className="font-sans text-[11px] font-semibold">
                      Users
                    </span>
                  </Link>
                  <Link
                    href="/dashboard/settings/audit-logs"
                    className={`w-full flex items-center pl-14 pr-6 py-2 transition-colors duration-200 text-left focus:outline-none ${pathname.includes("/settings/audit-logs")
                        ? "text-primary font-bold bg-surface-container-low/50"
                        : "text-on-surface-variant hover:bg-surface-container-low"
                      }`}
                  >
                    <ShieldAlert className="mr-2 w-4 h-4 shrink-0" />
                    <span className="font-sans text-[11px] font-semibold">
                      Audit Logs
                    </span>
                  </Link>
                </>
              )}
              <Link
                href="/dashboard/settings/sla"
                className={`w-full flex items-center pl-14 pr-6 py-2 transition-colors duration-200 text-left focus:outline-none ${pathname.includes("/settings/sla")
                    ? "text-primary font-bold bg-surface-container-low/50"
                    : "text-on-surface-variant hover:bg-surface-container-low"
                  }`}
              >
                <Clock className="mr-2 w-4 h-4 shrink-0" />
                <span className="font-sans text-[11px] font-semibold">
                  SLA Configuration
                </span>
              </Link>
            </div>
          )}
        </div>
      </nav>

      {/* Footer Sign Out */}
      <div className="shrink-0 border-t border-table-border p-3 pb-6 md:pb-3 mt-auto bg-surface-container-lowest">
        <button
          type="button"
          onClick={handleLogout}
          className={`w-full flex items-center px-3 py-2.5 rounded-md text-status-error hover:bg-red-50/70 border border-transparent hover:border-red-200 transition-colors duration-200 focus:outline-none cursor-pointer ${
            isCollapsed ? "justify-center" : ""
          }`}
          title={isCollapsed ? "Sign Out" : undefined}
        >
          <LogOut className={`w-5 h-5 shrink-0 text-primary ${isCollapsed ? "" : "mr-3"}`} />
          {!isCollapsed && (
            <span className="font-sans text-xs font-bold text-primary">Sign Out</span>
          )}
        </button>
      </div>
    </aside>
  </>
);
}
