# Changelog

All notable changes to the **DPP Recruitment Portal Dashboard** project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).

## [Phase 4.8 Sidebar Official Logo & Header Dynamic Breadcrumbs] — Sidebar Logo Display, Brand Text Cleanup, and Dynamic Breadcrumbs Header — 2026-11-16

### Added
- **GitHub Code Owners Configuration (`.github/CODEOWNERS`):**
  - Configured `@itdpp` as the global code owner (`* @itdpp`) for pull request review automation and branch ruleset approval.

### Fixed
- **Database Schema Sync for Job Opening Description (`prisma/migrations/20261115110000_add_job_opening_deskripsi/migration.sql`):**
  - Added dedicated Prisma migration adding column `JobOpening.deskripsi` (`ALTER TABLE "JobOpening" ADD COLUMN "deskripsi" TEXT;`).
  - Resolves runtime database schema mismatch error on staging/production environments where `JobOpening.deskripsi` column did not exist, fixing `/dashboard/pipeline` and `/dashboard/generate-documents`.
- **Collapsed Sidebar DPP Mark Visibility (`components/layout/Sidebar.tsx`, `components/layout/CandidateSidebar.tsx`, `public/images/branding/dpp-icon.png`, `app/icon.png`, `public/icon.png`):**
  - Resolved issue where collapsing the sidebar rendered an invisible icon: legacy `/icon.png` and `app/icon.png` were white monochrome icons (#ffffff) blending completely into the white container background.
  - Generated dedicated high-resolution, centered corporate red DPP logo mark (`/images/branding/dpp-icon.png`, 512x512) directly from official corporate assets.
  - Updated both admin and candidate sidebars to use `/images/branding/dpp-icon.png` with `unoptimized priority`, ensuring crisp visibility when collapsed.
  - Updated `app/icon.png` and `public/icon.png` so the application favicon consistently displays the corporate red DPP logo mark.

### Changed
- **Main & Candidate Sidebar Branding (`components/layout/Sidebar.tsx`, `components/layout/CandidateSidebar.tsx`):**
  - Replaced placeholder icon box and static typography with official high-resolution corporate logo `/images/branding/dpp-logo-new.png` (`priority`, `h-10` for admin, `h-8` for candidate).
  - Centered icon mark when sidebar is collapsed (`isCollapsed === true`).
  - Removed text "DIAN PANDU PRATAMA", subtitle "E-Recruitment Portal", and badge "Labor & Job Supply" from sidebar headers as requested.
  - Wrapped branding in accessible `<Link href="/dashboard">` (and `/candidate/jobs` for candidates).
- **Dynamic Navbar Breadcrumbs (`components/layout/Header.tsx`):**
  - Replaced static brand status line ("PT Dian Pandu Pratama • E-Recruitment Portal • Labor & Job Supply") with dynamic, hierarchical breadcrumb navigation powered by `usePathname()`.
  - Comprehensive segment dictionary `ROUTE_LABELS` covering all internal dashboard routes, master data tables, recruitment pipeline, audit logs, SLA configuration, and candidate portal.
  - Interactive breadcrumbs featuring `<Home />` icon leading to `/dashboard`, clickable ancestor crumbs, chevron dividers (`<ChevronRight />`), and bold active leaf node indicator (`#0A2540`).
  - Automatic detection and humanization of dynamic CUID/UUID identifiers into clean `"Detail"` crumbs.

## [Phase 4.7 Landing Redirection, Login & Register UI Polish] — Dedicated Jobs Route, Clean Auth Panels, and Register Header Space-Between — 2026-11-15

### Changed
- **Dedicated Job Listings Routing (`app/page.tsx`, `components/landing/LandingNavbar.tsx`):**
  - Updated navbar "Lowongan Kerja" (desktop and mobile) and hero CTA button "Cari Lowongan" to route directly to `/jobs`.
  - Removed embedded `<section id="lowongan">` and unused data queries from the landing page to focus all job browsing on the dedicated, high-performance `/jobs` route.
- **Login Page Brand Cleanup (`app/login/page.tsx`):**
  - Re-encoded and fixed `dpp-logo-white-text.png` with standard PNG filter-0 scanlines and valid CRCs, resolving the invisible logo bug on the navy left panel.
  - Removed redundant logo and "Portal Masuk E-Recruitment" badge from the right form panel.
  - Styled login submit button with corporate DPP red (`bg-[#C81E25] hover:bg-[#A8181E]`).
- **Register Page UI Refinements (`app/candidate/register/page.tsx`):**
  - Restructured top bar with `flex items-center justify-between` layout, separating "Kembali ke Beranda" and the official DPP logo.
  - Removed legacy text "E-Recruitment Portal • PT Dian Pandu Pratama".
  - Removed icon from "Daftar Sekarang" submit button, standardizing to solid text and corporate red color scheme.

## [Phase 4.6 Shared Landing Footer & Sticky Jobs Filter] — Unified Corporate Bright Footer and Sticky Job Search Bar — 2026-11-15

### Added
- **Reusable Corporate Landing Footer (`components/landing/LandingFooter.tsx`):**
  - Modularized the high-contrast bright theme footer (`bg-zinc-100`, 4-column layout) featuring DPP corporate branding, Jababeka plant address, hotline/email contacts, quick links (dpp.co.id, /jobs, /#jaringan-operasi, /#budaya-smart), and UU PDP compliance notice.
  - Deployed consistently across `/`, `/jobs` (job listings), and `/jobs/[slug]` (job details), replacing legacy dark footers.

### Changed
- **Sticky Job Filter & Search Bar (`app/jobs/PublicJobsClient.tsx`):**
  - Added sticky positioning behavior (`sticky top-20 z-30 py-3 -my-3 bg-[#F8FAFC]/95 backdrop-blur-md`) when reaching the top of the viewport underneath the navbar on `/jobs`.
  - Enables seamless real-time search, department filtering, and province filtering while scrolling through job listing cards.
- **Unified Footer Implementation (`app/page.tsx`, `app/jobs/page.tsx`, `app/jobs/[slug]/page.tsx`):**
  - Adopted `<LandingFooter />` across all public-facing pages for brand consistency.

## [Phase 4.5 Public Jobs Page Polish] — Logo-Only Navbar, Corporate Red Login Button, and Full Manpower Background Banner — 2026-11-15

### Changed
- **Header Navbar Cleanliness (`app/jobs/page.tsx`):**
  - Standardized navbar to match `/jobs/[slug]` and `/login`, replacing the old composite box/badge with the clean official DPP logo mark (`/images/branding/dpp-logo-new.png`).
- **Brand-Aligned CTA Colors (`app/jobs/page.tsx`):**
  - Changed the "Masuk" button styling from dark navy background with emerald icon (`bg-[#0A2540]`, `text-emerald-400`) to solid DPP corporate red (`bg-[#C81E25] hover:bg-[#A8181E] text-white`) with white icon `<LogIn className="text-white" />`.
  - Refined "Daftar Karir" button to clean neutral outline (`border-zinc-900 text-zinc-900 hover:bg-zinc-900 hover:text-white`).
- **Full Manpower Background Hero Banner (`app/jobs/page.tsx`):**
  - Replaced the generic flat CSS linear gradient with high-resolution photographic background `manpower.png` (`/images/branding/manpower.png`) with full-width responsive bleed (`sizes="100vw"`).
  - Applied subtle dual-layer dark gradient overlay ensuring high contrast, enterprise polish, and optimal text legibility for heading, summary, and competence badges.

## [Phase 4.4 Job Detail Polish] — Clean Logo Navbar, Brand-Aligned CTA, and Job Description Field with Backfill — 2026-11-15

### Added
- **Job Description Schema & Field (`deskripsi` in `prisma/schema.prisma`):**
  - Added nullable `deskripsi String?` column to `JobOpening` model in PostgreSQL.
  - Added validation rule `deskripsi: z.string().optional()` to `lib/validations/job.ts`.
  - Added "Deskripsi Pekerjaan (Job Description)" textarea field in both admin job creation (`app/dashboard/job-openings/create/JobCreateClient.tsx`) and edit forms (`app/dashboard/job-openings/[id]/edit/JobEditClient.tsx`).
- **Automated Job Description Backfill Script (`scripts/backfill-job-descriptions.ts`):**
  - Populated comprehensive, enterprise-grade job descriptions for all 13 active job openings in PostgreSQL covering roles across heavy equipment operations, engineering, HSE, mechanics, geology, and technical staff.
  - Registered `npm run backfill:descriptions` npm script in `package.json`.
- **Public Job Detail Display (`app/jobs/[slug]/page.tsx`):**
  - Rendered "Deskripsi Pekerjaan" section with `<Briefcase />` icon right above "Kualifikasi & Persyaratan".

### Changed
- **Header Navbar Cleanliness (`app/jobs/[slug]/page.tsx`):**
  - Replaced legacy compound badge/icon with the official clean DPP corporate logo (`/images/branding/dpp-logo-new.png`), matching the minimalist aesthetic of the login page header.
- **Color Identity & CTA Polish (`app/jobs/[slug]/page.tsx`):**
  - Eliminated conflicting dark blue and green font color combinations.
  - Changed primary CTA button "Masuk & Lamar Sekarang" to solid DPP corporate red (`#C81E25`, `hover:bg-[#A8181E]`) with white typography and white `<LogIn />` icon.
  - Updated secondary button to crisp neutral slate outline.
  - Updated request status badge to neutral `bg-zinc-100 text-zinc-800 border-zinc-200`.
  - Standardized section heading icons (`CheckCircle2`, `ShieldCheck`) to DPP primary red accent (`#C81E25`).

## [Phase 4.3 SEO URLs] — Human-Readable Job Slugs & Seamless Backward Compatibility — 2026-11-15

### Added
- **SEO & Human-Readable URL Slug Generation (`lib/slug.ts`):**
  - Utility functions `slugify` and `generateJobSlug` producing standardized `/jobs/{posisi}-at-{customer}` paths with accent stripping, sanitization, and automatic suffix disambiguation.
- **Database Schema Column (`prisma/schema.prisma`):**
  - Added `slug String? @unique` to `JobOpening` model in PostgreSQL.
- **Automated Backfill Script (`scripts/backfill-job-slugs.ts`):**
  - Populated unique SEO slugs across all 13 active job openings in the database.
- **Unit Testing Suite (`lib/__tests__/slug.test.ts`):**
  - Added unit test coverage for slug generation, sanitization, customer attribution, and suffix formatting (20/20 unit tests pass).
- **Singular URL Redirection (`app/job/[slug]/page.tsx`):**
  - Support for `/job/{slug}` gracefully forwarding to `/jobs/{slug}`.

### Changed
- **Next.js Route Migration (`app/jobs/[slug]/page.tsx`):**
  - Migrated dynamic route from `app/jobs/[id]` to `app/jobs/[slug]`.
  - Implemented automatic 301 permanent redirect if accessed via legacy CUID ID (`/jobs/cmw0...`), ensuring zero broken bookmarks or indexing issues.
- **Server Action Enhancements (`app/actions/job.ts`):**
  - Updated `createJobOpening` to automatically resolve position and customer names to generate unique slugs on job creation.
  - Updated `getPublicJobById` to support query by either `slug` or `id`.
- **Public Jobs Link Integration (`app/jobs/PublicJobsClient.tsx`):**
  - Updated job cards to navigate to `/jobs/${job.slug || job.id}`.

## [Phase 4.2 Polish] — Manpower Formation Full Height, Hero Width Alignment, Overlaid Map Section & Borderless Imagery — 2026-11-15

### Changed
- **Dropdown Navigasi "Tentang Kami" Fix (`components/landing/LandingNavbar.tsx`):**
  - Resolved hover-gap issue by implementing a continuous top-full padding bridge (`top-full pt-1.5`) and click-outside handler (`useRef` + `mousedown` listener), making dropdown options effortless and reliable to select.
- **Hero Ambient Glow Cleanup (`app/page.tsx`):**
  - Removed top-right red gradient blur orb to maintain a clean, open, and confident corporate canvas.
- **Manpower Formation Showcase Refinement (`components/landing/ManpowerFormationShowcase.tsx`):**
  - Removed tab switcher buttons and active tab state; streamlined to showcase the unified standardized manpower lineup (`manpower-formation.jpg`).
  - Adjusted card height (`h-[320px] sm:h-[370px] lg:h-[390px] xl:h-[420px]`) to fill the hero column height seamlessly without overflowing into the 100vh bottom marquee.
  - Removed tab description badge from the bottom information overlay.
- **Mitra & Klien Width Alignment (`app/page.tsx`):**
  - Aligned partner/client marquee container width with the Hero section content grid (`max-w-7xl mx-auto px-4 sm:px-6 lg:px-8`), keeping the layout cohesive and strictly within the content boundaries.
- **Jaringan Operasi Nasional Layout Alignment (`app/page.tsx`):**
  - Aligned section header position to match Budaya S.M.A.R.T and Fokus Utama Bisnis (`max-w-3xl mb-12` left-aligned on clean white canvas).
  - Placed title and description completely above the map diagram to ensure 100% legibility and zero collision with map annotations.
  - Removed the 3 Hub cards (`HUB-01`, `HUB-02`, `HUB-03`) and removed the badge element "Distribusi Operasional & Jangkauan Penempatan".
- **Job & Labour Supply Photo Border Removal (`welder-specialist.jpg` & `app/page.tsx`):**
  - Cleanly cropped off outer offset frame edges from the source image.
  - Enhanced scale styling with `scale-110 group-hover:scale-115 object-center` to guarantee zero border visibility.

## [Phase 4.1 Polish] — Hero 100vh Consolidation, Manpower Formation Showcase, Map Background Integration & Enterprise Typography — 2026-11-15

### Added
- **Interactive Manpower Formation Showcase (`components/landing/ManpowerFormationShowcase.tsx`):**
  - Component showcasing standardized team lineups with interactive tab toggling between **Site Technical Crew** (`public/images/branding/manpower-formation.jpg`) and **Engineering & Back Office** (`public/images/branding/manpower-backoffice.jpg`).
  - Integrated fit-to-work, K3, and BNSP qualification tags.
- **High-Resolution Operational Footprint Map Background:**
  - Integrated official high-resolution `dpp-operational-map.png` as a non-stretched background watermark preserving 100% native aspect ratio.

### Changed
- **Navbar Button Refinement (`components/landing/LandingNavbar.tsx`):**
  - Enhanced "Daftar Karir" (crisp zinc-900 border) and "Masuk Portal" (`#C81E25` high-contrast) buttons.
  - Removed icons (`UserPlus`, `LogIn`) so the CTA navigation feels bold, firm, and authoritative.
- **Hero Section 100vh Consolidation (`app/page.tsx`):**
  - Consolidated Hero content and "Mitra & Klien Strategis" carousel into a unified 100vh desktop viewport.
  - Integrated `ClientLogosCarousel compact={true}` directly at the bottom bar of the Hero container, eliminating unnecessary scroll friction.
  - Removed Quick Metrics Ribbon and K3/BNSP floating overlay badge.
- **Jaringan Operasi Nasional Overhaul (`app/page.tsx`):**
  - Replaced generic cards with an architectural/technical 3-hub directory: **HUB-01 (ID-JB Cikarang HQ & Plant)**, **HUB-02 (ID-KI Kalimantan Timur Mining Sites)**, and **HUB-03 (ID-KS/KT Kalsel & Kalteng Hauling Corridor)**.
  - Removed "Lihat Sebaran di Dashboard Geosource".
- **Enterprise Typography & Anti-Slop Polish:**
  - Removed arbitrary inline colored spans (`#D9232A`) in headings.
  - Standardized on solid, authoritative `text-zinc-950` typography with restrained `#C81E25` corporate accents matching Astra / United Tractors enterprise standards.
- **Fokus Utama Bisnis Photographic Cards:**
  - Integrated real photographic cards (`welder-specialist.jpg`, `dpp-plant.jpg`, `manpower-backoffice.jpg`) on clean white canvas with zero black background.

## [Phase 4 Branding] — Corporate Visual Alignment & Industrial Identity (dpp.co.id) — 2026-11-13

### Added
- **Official Brand Mark & Logo Assets:**
  - `public/images/branding/dpp-logo-new.png`: Official PT Dian Pandu Pratama mark uploaded by IT Leader.
  - `public/images/branding/dpp-logo-white-text.png`: Pure white text version for dark and transparent backgrounds with original red `dp` mark.
  - `public/images/branding/smart-culture-banner.png`: Official S.M.A.R.T culture banner graphic uploaded by IT Leader.
  - `public/images/branding/clients/`: Official customer/client logo assets uploaded by IT Leader:
    - `patria-astra.png`: PATRIA member of ASTRA
    - `triatra.png`: TRIATRA
    - `united-tractors.png`: UNITED TRACTORS member of ASTRA
    - `patria-maritim-perkasa.png`: PATRIA maritim perkasa
    - `patria-maritime-lines.png`: PATRIA maritime lines
  - `components/landing/LandingNavbar.tsx`: Transparent responsive navbar featuring official DPP logo-only branding, smooth scroll transition to white glass backdrop, and consolidated navigation menu.
  - `components/landing/ClientLogosCarousel.tsx`: Horizontal scrolling and infinite marquee carousel presenting the 5 official client logo assets in high-resolution transparency.
- **Industrial Visual Assets:**
  - Integrated official photographs uploaded by IT Leader into `public/images/branding/`:
    - `dpp-plant.jpg`: Industrial Eco-Greenplant PT DPP Cikarang (Jababeka XII) with PATRIA 02 utility vehicle.
    - `welder-specialist.jpg`: Skilled welding specialist in heavy equipment PPE & sparks, representing DPP's core *Job & Labour Supply* capability.
    - `dpp-operational-map.png`: Official PT DPP Indonesia Operational Footprint Map (Head Office Cikarang, Sangatta KPC, Melak PATRIA/TRUST, Tabang IPR, Balikpapan Manggar, Batu Kajang, Tanjung Redep Berau, Tanjung Tabalong, Muara Teweh, Banjarmasin, Sungai Danau).
- **DPP Corporate Design System Tokens (`app/globals.css`):**
  - Added primary brand colors matching `dpp.co.id` and the Astra/United Tractors ecosystem: `--color-dpp-red: #D9232A;`, `--color-dpp-red-hover: #B91C1C;`, `--color-dpp-navy: #0A2540;`, `--color-dpp-slate: #1E293B;`, `--color-dpp-amber: #D97706;`.
  - Added infinite horizontal CSS marquee animations (`@keyframes marquee`, `.animate-marquee`).

### Changed
- **Penyelarasan Identitas Job Portal DPP & Perubahan Tata Letak (Layout Overhaul):**
  - **Identitas Job Portal Sejati**: Mengubah tajuk dan pesan pada Hero section agar secara lugas merepresentasikan platform pencarian kerja dan rekrutmen resmi PT Dian Pandu Pratama, dilengkapi bilah pencarian interaktif (*quick job search*), tag posisi populer (*Welder, Mekanik, Surveyor, K3*), dan tombol aksi pelamar.
  - **Penataan Ulang Urutan Seksi (Section Order)**:
    1. Hero Section (100vh, identitas job portal cerah dengan elemen *overlay*)
    2. Mitra & Klien Strategis (Carousel 5 logo resmi klien segera setelah Hero)
    3. Jangkauan Operasional Nasional (Peta sebaran site tambang dengan badge mengambang)
    4. Budaya Perusahaan S.M.A.R.T (Hanya menampilkan kartu nilai tanpa gambar banner)
    5. Fokus Utama Bisnis PT DPP (Menggunakan fotografi riil juru las & greenplant, berlatar cerah tanpa background hitam)
    6. Lowongan Kerja Aktif (`PublicJobsClient`)
    7. Footer Korporat
  - **Penyempurnaan Kartu Budaya S.M.A.R.T**: Menghapus gambar banner dan menata ubin 3D berada di atas kata nilai dengan margin horizontal longgar, sehingga kata terpanjang `Responsibility` memiliki ruang bernapas proporsional dan tidak mepet tepi kartu.
  - **Fokus Utama Bisnis Berbasis Fotografi Riil**: Mengganti ikon generik dengan kartu foto autentik (`welder-specialist.jpg` untuk Job & Labour Supply, `dpp-plant.jpg` untuk Product Support & Fabrication) pada kartu berlatar putih bersih.
  - **Penghapusan Total Elemen YKBUT**: Menghapus seluruh logo, label, dan kalimat yang menyebutkan YKBUT / Yayasan Karya Bakti United Tractors di seluruh halaman dan komponen (landing page, login, register, jobs, header, sidebar, geosource).
  - **Perbaikan Logo pada Kartu Login**: Menyematkan logo resmi PT DPP (`dpp-logo-new.png`) langsung pada kartu formulir login (`/login`) serta memperbarui panel kiri.
- **Bright Corporate Visual Identity (Anti "Menutup Diri"):**
  - Replaced dark backgrounds with bright, open, prestigious surfaces (`bg-gradient-to-b from-white via-zinc-50 to-[#F8FAFC]`, `bg-zinc-50`, `bg-white`) on Hero, Operational Network, and footer.
  - Hero section (100vh) now features multi-layered **UI Overlay Elements**:
    - Welder specialist visual base card with high-impact K3/BNSP badge.
    - Overlapping floating Eco-Greenplant Jababeka card breaking the visual grid.
    - Floating K3 & BNSP certification badge on the top-right corner.
    - Floating quick metrics ribbon.
  - Operational Network section now uses a bright theme with floating overlay badges (Head Office tag & 10+ Site coverage badge) anchored over the official Indonesia operational map.
  - Section Budaya Perusahaan: Removed the redundant subtitle sentence `"Nilai Utama S.M.A.R.T Pondasi etika kerja dan karakter profesional seluruh insan PT Dian Pandu Pratama."` so that the official S.M.A.R.T banner and 3D tiles take center stage directly.
  - Section Mitra & Klien: Replaced previous logos with the 5 official client logos uploaded by the IT Leader (PATRIA ASTRA, TRIATRA, UNITED TRACTORS, PATRIA Maritim Perkasa, PATRIA Maritime Lines).
  - Official DPP logo (`dpp-logo-new.png`) is prominently visible in the transparent navbar and footer against bright surfaces.
- **Public Jobs Portal (`app/jobs/page.tsx` & `app/jobs/[id]/page.tsx`):**
  - Redesigned with DPP Corporate Navy headers, category badges for mining & heavy equipment trades (Welder 6G/4G, Heavy Equipment Mechanic, Assembler, Mine Surveyor), and client placement tags.
  - Detail page includes K3 safety certification, BNSP requirements, and UU PDP data privacy badges.
- **Authentication Pages (`app/login/page.tsx` & `app/candidate/register/page.tsx`):**
  - Redesigned `/login` into an industrial split-screen layout with left brand showcase (welder visual, S.M.A.R.T badge, corporate partner marquee, UU PDP notice) and right clean login card.
  - Updated `/candidate/register` with official DPP branding and clear consent terms for PDP No. 27/2022.
- **Internal Navigation Layouts:**
  - Recruiter Sidebar (`components/layout/Sidebar.tsx`): Header updated with DPP logo, "DIAN PANDU PRATAMA", "E-Recruitment • YKBUT", and "Labor & Job Supply" badge.
  - Candidate Sidebar (`components/layout/CandidateSidebar.tsx`): Header aligned with DPP logo, "DIAN PANDU PRATAMA", and "Candidate Portal • YKBUT".
  - System Header (`components/layout/Header.tsx`): Replaced generic subtitle with "PT Dian Pandu Pratama • E-Recruitment Portal (YKBUT) • Labor & Job Supply".
  - GeoSource Dashboard (`app/dashboard/geosource/page.tsx`): Contextualized with DPP's nationwide sites and vocational sourcing pipeline (BLK/LPK/SMK).

## [Unreleased] — Revamp Option B: Phase 3 (UI/UX De-slopping, Bulk Actions & Recruiter Efficiency) — 2026-11-13

### Added
- `docs/adr/ADR-009-bulk-actions-and-recruiter-efficiency.md`: Architecture Decision Record for Kanban multi-selection, bulk server actions, spreadsheet bulk import with field-level encryption, and modern web guidelines compliance.
- `lib/__tests__/bulk-actions.test.ts`: 4 automated unit tests verifying 16-digit NIK cleaning and validation, AES-256-GCM encryption & HMAC-SHA256 blind indexing for imported candidates, offering letter lock guard logic, and standardized rejection reason normalization.
- `app/api/candidates/import-template/route.ts`: Secure endpoint generating the official candidate import spreadsheet template (`Template_Import_Kandidat_DPP.xlsx`) via `exceljs`, featuring DPP Navy headers, formatted text `@` cells for NIK/KK, 3 realistic mining labor supply sample rows, and an explicit UU PDP compliance guideline sheet.
- `components/dashboard/BulkImportModal.tsx`: Accessible interactive modal for dragging & dropping Excel spreadsheets, client-side parsing and validation preview table, error detection for invalid NIKs/names, and batch submission to the database.
- **Bulk Server Actions in `app/actions/job.ts`:**
  - `bulkAdvanceApplicationStage(appIds, targetStageId, note)`: Batch candidate stage advancement with Offering Letter confirmation locks, automatic status transitions (`ACTIVE` $\rightarrow$ `HIRED`), live job headcount synchronization, and `BULK_STAGE_MOVED` audit trail logging.
  - `bulkRejectApplications(appIds, rejectionReason)`: Standardized multi-applicant rejection recording `status = REJECTED`, reason notes, headcount recalculation, and `BULK_REJECTED` audit logs.
  - `bulkAddToTalentPool(candidateProfileIds)`: Batch marking of candidates as talent pool assets with `BULK_TALENT_POOL_ADDED` audit logging.
  - `bulkAssignCandidatesToJob(candidateProfileIds, targetJobId)`: Direct batch assignment of talent pool candidates into active job openings at Stage 1 (CV Screening).
  - `bulkImportCandidates(jobId, candidates)`: Batch import handler for up to 500 candidates per execution, with blind index deduplication (`nikHash`), field-level encryption (`encryptField`), auto-generated user credentials, and initial assessment creation.

### Changed
- **Kanban Board Multi-Selection (`components/PipelineBoard.tsx` & `app/dashboard/pipeline/PipelineClient.tsx`):**
  - Added checkboxes on each candidate card with selection highlight and non-interfering click handlers.
  - Added "Pilih Semua di Kolom Ini" toggle button on each stage column header.
  - Added a floating sticky bottom action bar (*Sticky Bottom Bulk Bar*) styled in DPP Corporate Navy (`#0A2540`), enabling recruiters to advance stages, reject applicants in bulk, or send profiles to the talent pool with one click.
- **Job Detail Page (`app/dashboard/job-openings/[id]/JobDetailClient.tsx`):**
  - Integrated "+ Import Massal Excel" button in the job detail header actions.
  - Applied Modern Web Guidance for responsive tables: wrapped hired candidate list with `<div tabIndex={0} role="region" aria-label="Tabel Kandidat Terpilih" className="overflow-x-auto focus:outline-hidden overscroll-x-contain">` and sticky headers.
- **Talent Pool Page (`app/dashboard/talent-pool/TalentPoolClient.tsx` & `app/dashboard/talent-pool/page.tsx`):**
  - Added "+ Import Massal Excel" button allowing direct profile imports into the talent pool.
  - Added table row multi-selection checkboxes with "Select All" column header control.
  - Added sticky floating bulk action bar with "Tugaskan ke Lowongan..." modal to assign selected candidates to active job openings.
  - Applied Modern Web Guidance: wrapped table with `role="region"`, `aria-label="Tabel Talent Pool Kandidat"`, and sticky headers.
- **UI/UX De-slopping:**
  - Removed gratuitous AI slop (over-saturated card gradients, blurry glassmorphism borders) in favor of crisp DPP Navy (`#0A2540`), Slate (`#F8FAFC` & `#E2E8F0`), Emerald (`#059669`), and Rose (`#DC2626`).
- **End-to-End Verification (`scripts/e2e-page-check.ts`):**
  - Added section [7] testing Fase 3 Server Actions, Excel template generation, and PDP blind indexing / encryption.
  - Added `npm run check:e2e` script to `package.json` for one-command platform integrity verification (**21/21 checks passing**).

## [Phase 2] — Revamp Option B: Phase 2 (Database Normalization & UU PDP Compliance) — 2026-11-13

### Added
- `docs/adr/ADR-008-database-normalization-and-pdp-compliance.md`: Architecture Decision Record covering stage data relational normalization, UU PDP No. 27/2022 compliance, and field-level AES-256-GCM encryption.
- `lib/crypto.ts`: Field-Level Encryption utility using **AES-256-GCM** (96-bit random IV, 128-bit authentication tag, `enc:v1:` prefix) and **HMAC-SHA256 Blind Indexing** for fast database lookups without decrypting PII.
- `lib/__tests__/crypto.test.ts`: 7 unit tests verifying encryption round-trips, anti-tampering validation, legacy plaintext fallback, deterministic blind index hashing, and presentation NIK masking.
- `scripts/run-all-tests.ts`: Unified test runner executing all 13 security, domain, and cryptographic unit tests.
- `scripts/migrate-stagedata-to-relational.ts` (`npm run db:migrate:fase2`): Idempotent, non-destructive migration script that transforms historical untyped JSON `stageData` into normalized relational models, protects candidate PII, and initializes job quota metrics.
- `prisma/migrations/20261113140000_fase2_normalization_and_pdp/migration.sql`: Zero-downtime PostgreSQL migration creating formal relational tables, enums, soft delete columns, and composite indexes.
- **Relational Domain Models in `prisma/schema.prisma`:**
  - `ApplicationAssessment`: Structured scoring and records for CV Screening, HR Interview, Psikotes, Skill Test, User Interview, and BNSP Certification Validation.
  - `MedicalCheckUp`: Structured MCU scheduling, clinic tracking, fitness classification (`FIT`, `FIT_WITH_RESTRICTION`, `TEMPORARY_UNFIT`, `UNFIT`), candidate proof attachments, and AES-256-GCM encrypted health diagnoses (`doctorNotesEncrypted`).
  - `OfferingLetterRecord`: Formal offering letter status lifecycle (`DRAFT`, `SENT`, `ACCEPTED`, `DECLINED`, `REJECTED_FINAL`), signed document keys, and encrypted compensation data.
  - `ContractMobilization`: Mining labor supply tracking with PKWT contract number, site NRP, Mine Permit/SIMPER number, induction dates, BAST status, and mobilization progression (`PENDING` $\rightarrow$ `ARRIVED_ON_SITE`).

### Changed
- **Candidate Profile & Privacy (UU PDP Compliance):**
  - Updated `CandidateProfile`: added `nikHash String? @unique` (Blind Index) and `deletedAt DateTime?` (Soft Delete).
  - Updated `app/actions/candidate-profile.ts` to transparently encrypt `nik` and `kk` on storage and decrypt on retrieval, preventing duplicate registration via `nikHash`.
- **Job Headcount Tracking (Labor Supply Alignment):**
  - Updated `JobOpening`: added `headcountTarget`, `headcountFulfilled`, and `headcountOnSite` to track real client quota fulfillment.
  - Updated `updateApplicationStage` in `app/actions/job.ts` to automatically recalculate fulfilled and on-site headcounts whenever candidates advance stages.
- **Server Actions Relational Sync:**
  - Added `syncStageDataToRelational` in `app/actions/job.ts` to automatically sync all `stageData` updates into the new relational tables while retaining the legacy JSON for complete backward compatibility.
  - Updated `app/actions/candidate-application.ts` to sync candidate responses (Offering acceptance/decline and MCU proofs) directly into `OfferingLetterRecord` and `MedicalCheckUp`.
  - Updated `applyToJob` in `app/actions/job.ts` to enforce the single active application policy using indexed `nikHash` lookups.
- **Database Query Optimization:**
  - Added composite indexes: `JobOpening(status, customerId)`, `JobOpening(status, tanggalMasuk)`, `Application(jobId, status)`, `Application(candidateProfileId, status)`, and `CandidateProfile(isTalentPool, isBlacklisted, isArchived)`.

## [Phase 1 Hardening] — Revamp Option B: Phase 1 (Security & Dependency Hardening) — 2026-11-13

### Added
- `docs/adr/ADR-007-security-and-dependency-hardening.md`: Architecture Decision Record for server action auth guards, middleware API protection, and dependency elimination.
- Global API authentication and RBAC gate in `middleware.ts` covering `/api/*` with whitelisted public paths (`/api/auth/*` and `/api/health`).

### Changed
- **Server Actions RBAC Hardening:**
  - Enforced `requireStaffSession()` on previously unauthenticated pagination/filter server actions in `app/actions/job.ts`: `getPaginatedTalentPool`, `getPaginatedArchivedCandidates`, `getPaginatedBlacklistedCandidates`, `getPaginatedInterviewsDashboardData`, `getPaginatedJobOpenings`, and `getFilteredPipelineData` (mitigating critical candidate PII data leak).
  - Enforced `requireStaffSession()` on certification schema mutations in `app/actions/master-data.ts`: `createCertificationSchema`, `updateCertificationSchema`, `deleteCertificationSchema`, and `ensureExtendedPipelineStages`.
- **PII & Data Hygiene:**
  - Sanitized `lib/mcu-clinics.ts`: removed hardcoded staff names, personal mobile numbers, and corporate emails, replacing them with configurable generic fallbacks (`process.env.NEXT_PUBLIC_MCU_*`).
  - Purged `MOCK_MCU_CANDIDATES` merge logic from `app/dashboard/generate-documents/GenerateDocumentsClient.tsx` to prevent fake candidate data injection into real production documents.
- **Dependency Cleanup & Vulnerability Mitigation:**
  - Uninstalled vulnerable and unused dependencies: `xlsx` (Prototype Pollution & ReDoS vulnerability), `@tiptap/pm`, `@tiptap/react`, `@tiptap/starter-kit`, and `html-to-docx`.
  - Removed unused `xlsx` import in `lib/document-generator.ts`.

## [Phase 3] — (MVP Polish, Audit Log, Login Rate-Limiting & R2 Storage Consolidation) — 2026-11-03

### Added
- `AuditLog` model in `prisma/schema.prisma` and migration `20261103043000_add_audit_log`.
- `lib/audit-log.ts` service with automatic sensitive-field redaction (`sanitizeAuditMetadata`) and fail-safe logging (`recordAuditLog`).
- `app/api/audit-logs/route.ts` and `/dashboard/settings/audit-logs` Admin UI with search, action filtering, and CSV export (`§4.9` & `§8` Brief).
- `lib/rate-limit.ts` in-memory brute-force protection integrated into NextAuth `CredentialsProvider` (`5` failed attempts / `15` minutes lockout).
- `app/api/file/upload/route.ts` same-origin upload endpoint supporting Cloudflare R2 (`portal-recruitment` bucket) and local disk fallback without browser CORS issues.
- `lib/dummy-file-generator.ts` on-the-fly PDF 1.4 and SVG avatar generator for seeded candidate records.
- `prisma/ensure-db.ts` and `prisma/load-env.ts` for automated local database provisioning and seed script environment loading.
- `deploy/nginx/recruitment.dpp.co.id.conf` Nginx reverse proxy configuration and `docs/VM_AND_CPANEL_SETUP.md` deployment runbook for `https://recruitment.dpp.co.id`.

### Changed
- `lib/s3.ts`, `app/api/file/route.ts`, and `app/actions/upload.ts`: routed uploads and inline file previews directly through Cloudflare R2 (`getObjectFromS3`, `uploadBufferToS3`) with local and dummy fallback.
- `Dockerfile`, `entrypoint.sh`, and `docker-compose.yml`: removed legacy MinIO containers and hardcoded fallback credentials, bundled full `@prisma` runtime scope, and precompiled Prisma seed scripts (`seed-essential.js` & `seed-dummy.js`) into the runner image.
- `app/dashboard/settings/users/page.tsx` & `app/api/users/[id]/route.ts`: enabled Super Admin to edit user email, name, department, role, and reset passwords (including primary admin password rotation) with uniqueness and $\ge 8$ character validation.
- Expanded unit test suite in `lib/__tests__/security-foundation.test.ts` to 6 passing tests.

## [Phase 2] — Foundation, Security Hardening & Docker Alignment — 2026-11-03

### Added
- `lib/feature-flags.ts` for environment-driven toggling of Candidate Portal (`FEATURE_CANDIDATE_PORTAL`) and Public Jobs (`FEATURE_PUBLIC_JOBS`).
- `lib/auth-guard.ts` providing reusable RBAC guards (`requireAdminSession`, `requireStaffSession`, `requireRole`), S3/R2 object ownership verification (`isObjectKeyOwnedByUser`), and upload file metadata validation (`validateUploadMetadata`).
- `app/api/health/route.ts` database-backed healthcheck endpoint for Docker container monitoring.
- `.dockerignore` and `.github/workflows/ci.yml` for automated TypeScript and unit test verification.
- `lib/__tests__/security-foundation.test.ts` unit test suite covering feature flags, IDOR protection, and upload validation.

### Changed
- **Security Hardening:**
  - Protected `GET/POST /api/users` and `PUT/DELETE /api/users/[id]` with `requireAdminSession()`, password length enforcement ($\ge 8$ chars), self-lockout prevention, and singleton Prisma client (`R-01`).
  - Added `requireStaffSession()` guards across internal Server Actions in `app/actions/dashboard.ts`, `app/actions/document.ts`, `app/actions/master-data.ts`, and `app/actions/job.ts` (`R-02`).
  - Secured `GET /api/file` and `getUploadUrl`/`getPreviewUrl` against IDOR and cross-folder path traversal (`R-04`).
  - Enforced authentication, strict MIME type allowlisting (`PDF`, `JPG`, `PNG`), and 5 MB limit in `app/actions/upload.ts` (`R-03`).
  - Updated `middleware.ts` and `POST /api/auth/register` to enforce `FEATURE_CANDIDATE_PORTAL` and `FEATURE_PUBLIC_JOBS` flags (`R-07`).
- **Docker & Shared VM Port Alignment:**
  - Enabled `output: "standalone"` in `next.config.ts` (`R-11`).
  - Updated `Dockerfile` to `node:20-slim` with `openssl`, `curl`, Prisma runtime artifacts, `PORT=3020`, and `HEALTHCHECK` (`http://localhost:3020/api/health`).
  - Reconfigured `docker-compose.yml` to use non-conflicting port `3020` for `app` and `127.0.0.1:5435` for `db` (avoiding VM conflicts on ports `3000`, `3001`, `5432`, `5433`), removed public bucket ACL command, and placed local MinIO under optional `local-minio` profile.

## [Phase 1] — Planning & Architecture Baseline — 2026-11-03

### Added
- **Project Governance & Portfolio Documentation (`docs/`):**
  - `docs/PROJECT_LOG.md` for chronological engineering log and decision tracking.
  - `docs/PRD.md` covering business goals, MVP scope, KPI definitions, user stories, acceptance criteria, and prototype gap analysis.
  - `docs/ARCHITECTURE.md` with system context, container deployment diagrams, ERD, and security boundary specifications.
  - `docs/RISK_REGISTER.md` cataloging 15 technical, security, compliance (UU PDP No. 27/2022), and infrastructure risks with concrete mitigations.
  - `docs/ESTIMATION_AND_COST.md` detailing sprint backlog, effort estimation, and OPEX/CAPEX comparison (Existing Azure VM + Cloudflare R2 vs Azure Managed Services).
  - `docs/TESTING_AND_DEPLOYMENT.md` defining QA strategy, Docker Compose hardening, backup/restore procedures, rollback runbook, and Developer Knowledge Transfer (KT) questionnaire.
  - `docs/PORTFOLIO_SUMMARY.md` summarizing business impact and technical leadership metrics.
  - Architecture Decision Records (`docs/adr/ADR-001` through `ADR-006`).

## [0.1.0-prototype] — Up to 2026-11-02 (Existing Developer Commits `5aaeb87`..`2d95345`)

### Added (Prototype Baseline)
- Next.js 16.2 (App Router) + React 19 + Tailwind CSS v4 + Prisma 5.15 + PostgreSQL schema and initial migrations.
- Recruiter/Admin Dashboard: executive summary, reports, pipeline funnel, regional distribution & Leaflet GeoMap, interview calendar, priority jobs.
- Master Data modules: Province, City, Customer, Site Operation (with custom SLA), Clinic/MCU, Position, Department, Institute/BLK, Certification, Certification Schema, Request Type, Rejection Message, Pipeline Stage SLA.
- Job Openings CRUD with registration numbers, B1 form reference, BNSP/skill test flags, and timeline generation.
- 10-stage Recruitment Pipeline (CV Screening, Interview HR, Psikotes, Technical Test, Interview User, Offering, MCU, Training, Induction, PKWT) with stage verification, document generation (Offering Letter, MCU, BAST), talent pool, archived candidates, and blacklist management.
- Candidate Portal prototype (login, registration, profile & S3/R2 document upload, job application, application history, message feed).

